chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type !== 'badge') return
  chrome.browserAction.setBadgeText({text: request.text.toString()})
})
