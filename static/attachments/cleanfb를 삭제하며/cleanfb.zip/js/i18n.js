;(global => {
  let currentLocale = global.navigator.language

  const en = {
    sponsored: 'Sponsored',
    reason_not_liked: "Status from a page you haven't liked",
    reason_not_friended: "Status from a user you haven't friended",
    reason_not_following: "Status from a user you haven't followed",
    source: 'Source',
    no_source: 'No source',
  }

  const ko = {
    sponsored: '광고 게시물',
    reason_not_liked: '좋아요 누르지 않은 페이지의 게시물',
    reason_not_friended: '친구 추가 하지 않은 사용자의 게시물',
    reason_not_following: '팔로우하지 않은 사용자의 게시물',
    source: '원본',
    no_source: '원본 없음',
  }

  const locales = {
    en,
    ko,
  }

  global.i18n = s => {
    const locale = locales[currentLocale] || en
    return locale[s]
  }
})(this);
