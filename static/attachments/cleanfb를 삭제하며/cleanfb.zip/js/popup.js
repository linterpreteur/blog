;(global => {
  const {i18n} = global

  chrome.tabs.query({active: true, currentWindow: true}, tabs => {
    chrome.tabs.sendMessage(tabs[0].id, {type: 'removed_nodes'}, response => {
      if (!response) return

      const html = response.map(item => {
        const {link, reason} = item
        const content = item.content.replace(/\n/g, '<br>').trim()
        const source = `<a href="${link}">${i18n('source')}</a>`
        const noSource = `(${i18n('no_source')})`
        return `<h3>${reason} ${link ? source : noSource}</h3><p>${content}</p>`
      }).join('')
      document.getElementById('content').innerHTML = html
    })
  })
})(this);
