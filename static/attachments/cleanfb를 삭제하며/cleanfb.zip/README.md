# CleanFB

![Preview](img/screenshot.png)

### What should be coming

* Filtering by user provided dictionary
* Filtering images similar to blocked ones
* Labeling other users
* Quick block button that simply triggers FB native block
* Let user configure filtering details
* Show users at popup why a post is blocked

### License

CC0 Public Domain
